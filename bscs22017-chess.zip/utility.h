#pragma once
#include<math.h>
#include"piece.h";
#include"chess.h";
#include"board.h";
class piece;
class board;
class validity:public chess
{
	

};

